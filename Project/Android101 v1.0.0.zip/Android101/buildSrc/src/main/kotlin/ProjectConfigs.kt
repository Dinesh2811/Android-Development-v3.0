object ProjectConfigs {
    const val namespace = "com.dinesh.android"
    const val compileSdkVersion = 34
    const val minSdkVersion = 24
    const val targetSdkVersion = 34
    const val javaVersion = 17
    const val kotlinCompilerExtensionVersion = "1.5.6"
    const val MYAPP_RELEASE_STORE_FILE = "../dinesh28-release-key.jks"
    const val MYAPP_RELEASE_STORE_PASSWORD = "dinesh28Android"
    const val MYAPP_RELEASE_KEY_ALIAS = "dinesh28-key-alias"
    const val MYAPP_RELEASE_KEY_PASSWORD = "dinesh28Android"

    const val MYAPP_UAT_STORE_FILE = "../dinesh28-release-key.jks"
    const val MYAPP_UAT_STORE_PASSWORD = "dinesh28Android"
    const val MYAPP_UAT_KEY_ALIAS = "dinesh28-key-alias"
    const val MYAPP_UAT_KEY_PASSWORD = "dinesh28Android"

    const val isBuildConfig = true
    const val isViewBinding = true
    const val isCompose = true

    const val isReleaseMinifyEnabled = true
    const val isReleaseShrinkResources = true
    const val isReleaseTest = false

    const val isDebugMinifyEnabled = false
    const val isDebugShrinkResources = false
    const val isDebugTest = false
}