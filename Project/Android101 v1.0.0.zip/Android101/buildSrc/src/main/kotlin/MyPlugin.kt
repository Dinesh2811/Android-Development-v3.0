import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.kotlin.dsl.dependencies

class MyPlugin : Plugin<Project> {
    override fun apply(project: Project) {
        val composeVersion = "1.6.0-beta02"
        val dependencies = listOf(
            "androidx.core:core-ktx:1.12.0",
            "androidx.activity:activity-compose:1.8.1",
            "androidx.compose.ui:ui:$composeVersion",
            "androidx.compose.ui:ui-graphics:$composeVersion",
            "androidx.compose.ui:ui-tooling-preview:$composeVersion",
            "androidx.compose.material3:material3:1.2.0-alpha12",
        )

        project.dependencies {
            dependencies.forEach { dependency ->
                add("implementation", dependency)
            }
            add("implementation", platform("androidx.compose:compose-bom:2023.10.01"))
        }
    }
}
