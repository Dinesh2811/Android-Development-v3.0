package v1

object Versions {
    const val compose = "1.4.3"
    const val composeMaterial3 = "1.1.1"
    const val composeCompiler = "1.4.6"
    const val hilt = "2.45"
    const val okHttp = "5.0.0-alpha.2"
    const val retrofit = "2.9.0"
    const val room = "2.5.0"
}