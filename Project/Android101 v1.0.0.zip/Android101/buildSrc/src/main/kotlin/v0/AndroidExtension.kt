package v0

import com.android.build.gradle.AppExtension
import com.android.build.gradle.BaseExtension
import com.android.build.gradle.LibraryExtension
import com.android.build.gradle.internal.plugins.AppPlugin
import com.android.build.gradle.internal.plugins.LibraryPlugin
import org.gradle.api.JavaVersion
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.api.plugins.JavaPlugin
import org.gradle.api.plugins.JavaPluginExtension
import org.gradle.api.plugins.PluginContainer
import org.gradle.kotlin.dsl.getByType


fun BaseExtension.configureAndroidBlock() {
    namespace = "com.dinesh.android"
    compileSdkVersion(34)
    buildToolsVersion("34.0.0")

    defaultConfig {
        minSdk = 24
        targetSdk = 34
        applicationId = "com.dinesh.android"
        versionCode = 1
        versionName = "1.0"
    }
//    buildTypes {
//        getByName("release") {
//            signingConfig = signingConfigs.getByName("debug")
//        }
//    }
}

class AndroidConfigPlugin : Plugin<Project> {
    override fun apply(project: Project) {
        project.plugins.withType(com.android.build.gradle.BasePlugin::class.java) {
            val androidExtension = project.extensions.getByType(BaseExtension::class.java)
            configureAndroidBlock(androidExtension)
        }
    }

    private fun configureAndroidBlock(android: BaseExtension) {
        android.apply {
            namespace = "com.dinesh.android"
            compileSdkVersion(34)
            buildToolsVersion("34.0.0")

            defaultConfig {
                minSdk = 24
                targetSdk = 34
                applicationId = "com.dinesh.android"
                versionCode = 1
                versionName = "1.0"
            }
//            buildTypes {
//                getByName("release") {
//                    signingConfig = signingConfigs.getByName("debug")
//                }
//            }
        }
    }
}




fun BaseExtension.defaultConfig() {

    compileSdkVersion(34)

    defaultConfig {
        minSdk = 30
        targetSdk = 34
        consumerProguardFiles("consumer-rules.pro")
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    composeOptions {
//        kotlinCompilerExtensionVersion = libs.versions.kotlinCompilerExtensionVersion.get()
        kotlinCompilerExtensionVersion = "1.5.6"
    }

    packagingOptions {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

fun PluginContainer.applyDefaultConfig(project: Project) {
    whenPluginAdded {
        when (this) {
            is AppPlugin -> {
                project.extensions
                    .getByType<AppExtension>()
                    .apply {
                        defaultConfig()
                    }
            }

            is LibraryPlugin -> {
                project.extensions
                    .getByType<LibraryExtension>()
                    .apply {
                        defaultConfig()
                    }
            }

            is JavaPlugin -> {
                project.extensions.getByType<JavaPluginExtension>()
                    .apply {
                        sourceCompatibility = JavaVersion.VERSION_17
                        targetCompatibility = JavaVersion.VERSION_17
                    }
            }

        }
    }
}
