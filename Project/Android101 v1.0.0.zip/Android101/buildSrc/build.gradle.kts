plugins {
    `kotlin-dsl`
}

gradlePlugin {
    plugins {
        register("module-plugin") {
            id = "module-plugin"
            implementationClass = "MyPlugin"
        }
    }
}

repositories {
    google()
    mavenCentral()
}

dependencies {
//    compileOnly(gradleApi())
//    implementation(kotlin("gradle-plugin", "1.3.72"))

    implementation("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.21")
    implementation("com.android.tools.build:gradle:8.2.0")
}

java.sourceCompatibility = JavaVersion.VERSION_17
java.targetCompatibility = JavaVersion.VERSION_17
