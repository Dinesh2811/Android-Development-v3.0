package com.dinesh.android.on_fly

import java.util.regex.Pattern


fun isValidEmail(email: String): Boolean {
    return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
}

fun isValidPassword(password: String): Boolean {
    val passwordPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$"
    val passwordMatcher = Pattern.compile(passwordPattern).matcher(password)

    return passwordMatcher.matches()
}