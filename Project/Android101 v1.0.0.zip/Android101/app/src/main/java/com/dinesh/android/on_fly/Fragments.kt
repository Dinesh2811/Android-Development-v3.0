package com.dinesh.android.on_fly

/*
Pass data from one Fragment to another (simple)

Fragment1
---
    private fun showOtpBottomSheet(email: String) {
        val bottomSheetFragment = VerifyOtpFragment().apply {
            arguments = Bundle().apply {
                putString("email", email)
            }
        }
        bottomSheetFragment.show(parentFragmentManager, bottomSheetFragment.tag)
    }
---

Fragment2
---
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val email = arguments?.getString("email")
        if (email != null) {
            Log.d("VerifyOtpFragment", "Email: $email")
            // Use the email as needed
        }
    }
---


 */

/*
Pass data from one Fragment to another (using Parcelable)

Fragment1
---
    private fun showOtpBottomSheet(signUpData: SignUpData) {
        val bottomSheetFragment = VerifyOtpFragment().apply {
            arguments = Bundle().apply {
                putParcelable("signUpData", signUpData)
            }
        }
        bottomSheetFragment.show(parentFragmentManager, bottomSheetFragment.tag)
    }
---

Fragment2
---
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val signUpData = arguments?.getParcelable<SignUpData>("signUpData")
        if (signUpData != null) {
            Log.d("VerifyOtpFragment", "SignUpData: $signUpData")
            // Use the signUpData as needed
        }
    }
---

SignUpData
---
@Parcelize
data class SignUpData(
    val email: String,
    val password: String,
    val deviceToken: String
) : Parcelable
---

 */



/*

            val bundle = bundleOf("email" to email)
            findNavController().navigate(R.id.action_forgotPasswordFragment_to_resetPasswordFragment2, bundle)


        // Retrieve the passed argument
        val email = arguments?.getString("email")
 */