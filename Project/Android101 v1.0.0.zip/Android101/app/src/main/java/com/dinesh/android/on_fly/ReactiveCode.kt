package com.dinesh.android.on_fly

/*
Flow: Fragment

        signupViewModel.isSignUpEnabled.onEach { }.launchIn(viewLifecycleOwner.lifecycleScope)


        lifecycleScope.launch {
            signupViewModel.signUpResult.collect { apiResponse ->

            }
        }



    val isSignUpEnabled = combine(
        _emailInputEditText,
        passwordInputEditText,
        confirmPasswordInputEditText,
        termsCheck
    ) { email, password, confirmPassword, isTermsChecked ->
        isValidEmail(email) && isValidPassword(password) && password == confirmPassword && isTermsChecked
    }.asLiveData()



    fun signUpUser(email: String, password: String, deviceToken: String) {
        viewModelScope.launch {
            signUpRepository.signUpUser(email, password, deviceToken)
                .catch { e ->
                    val error = e.message?: "Error during signup"
                    LogLevel.Error.log(TAG = "log_", message = error)
                    _signUpResult.value = SignUpResponse(status = error, data = null)
                }.collect { result ->
                    LogLevel.Debug.log(TAG = "log_", message = result.toString())
                    _signUpResult.value = result
                }
        }
    }

 */