package com.dinesh.android.on_fly

/*
OTP Screen:

        val otpFields = listOf(binding.editTextOtp1, binding.editTextOtp2, binding.editTextOtp3, binding.editTextOtp4)
        otpFields.forEachIndexed { index, editText ->
            editText.doAfterTextChanged {
                if (it != null && it.length == 1 && index != otpFields.size - 1) {
                    otpFields[index + 1].requestFocus()
                }

                if (otpFields.all { it.text.isNotEmpty() }) {
                    binding.verify.isEnabled = true
                    binding.verify.isClickable = true
                    Theme.setButtonTheme(textView = binding.verify, buttonTheme = Theme.ButtonTheme.DEFAULT, context = requireContext())
                } else {
                    binding.verify.isEnabled = false
                    binding.verify.isClickable = false
                    Theme.setButtonTheme(textView = binding.verify, buttonTheme = Theme.ButtonTheme.DISABLE, context = requireContext())
                }
            }
        }

 */

/*
BottomSheetDialog:

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return super.onCreateDialog(savedInstanceState).apply {
            window?.setDimAmount(0.8f)
            setOnShowListener {
                val bottomSheetDialog = it as BottomSheetDialog
                val bottomSheet = bottomSheetDialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet) as FrameLayout?
                bottomSheet?.setBackgroundResource(android.R.color.transparent)

                val params = window?.attributes
                params?.height = ViewGroup.LayoutParams.MATCH_PARENT
                window?.attributes = params
                window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            }
        }
    }

 */

