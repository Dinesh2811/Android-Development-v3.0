package com.dinesh.android.v1

// CalculatorLogic.kt
class CalculatorLogic {
    fun calculateResult(num1: Int, num2: Int): Int {
        return num1 + num2
    }
}
